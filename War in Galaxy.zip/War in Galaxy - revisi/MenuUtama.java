import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MenuUtama here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MenuUtama extends Menu
{

    /**
     * Constructor for objects of class MenuUtama.
     * 
     */
    public MenuUtama()
    {

        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
    }
}
